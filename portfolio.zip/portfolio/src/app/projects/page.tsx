

const ProjectPage = () => {
    return (
        <>
        <main className="main-grid text-white">
          Project
        </main>
        </>
    );
    }

export default ProjectPage;